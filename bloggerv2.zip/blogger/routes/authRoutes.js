const express = require("express");
const jwt = require("jsonwebtoken");
const cookieParser = require("cookie-parser");
const router = express.Router();

const User = require("../models/user.js");

// Middleware
router.use(cookieParser());

require("dotenv").config(); // Load environment variables from .env
const secretKey = process.env.SECRET_KEY;

router.get("/login", (req, res) => {
  res.render("admin/login.ejs");
});

// User Login
router.post("/login", async (req, res) => {
  const { username, password } = req.body;

  // Find the user by username
  const user = await User.findOne({ username });

  if (!user) {
    return res.status(401).send("Invalid username or password.");
  }

  // Compare the provided password with the stored hashed password
  const passwordMatch = user.password === password;

  if (!passwordMatch) {
    return res.status(401).send("Invalid username or password.");
  }

  // Create a JWT
  const token = jwt.sign({ username: user.username }, secretKey, {
    expiresIn: "1h",
  });

  // Set the JWT as a cookie
  res.cookie("token", token, { maxAge: 3600000 });

  res.redirect("/admin");
});

router.get("/logout", (req, res) => {
  res.clearCookie("token");

  res.redirect("/admin/login");
});

module.exports = router;
