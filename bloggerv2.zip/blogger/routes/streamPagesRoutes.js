const express = require("express");
const router = express.Router();

const sportsSchema = require("../models/sportsSchema.js");
const adsSchema = require("../models/adsSchema.js");

router.get("/:sportName/:id/:addition", async (req, res) => {
  try {
    const { sportName, id, additions } = req.params;

    const ads = await adsSchema.findOne();
    const sport = await sportsSchema.findOne({ sportName });

    if (!sport) {
      return res.status(404).render("err/404-page.ejs");
    }

    const selectedPage = sport.pages.find((page) => page.id === +id);

    if (!selectedPage) {
      return res.status(404).render("err/404-page.ejs");
    }

    res.render("streamPage.ejs", { ads, selectedPage });
  } catch (err) {
    console.error(err);
    res.status(500).send("Internal Server Error");
  }
});

module.exports = router;
