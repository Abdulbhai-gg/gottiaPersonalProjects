const express = require("express");
const jwt = require("jsonwebtoken");
const router = express.Router();
const sportsSchema = require("../models/sportsSchema.js");
const adsSchema = require("../models/adsSchema.js");

require("dotenv").config(); // Load environment variables from .env
const secretKey = process.env.SECRET_KEY;

// Middleware to check for and handle errors
router.use((err, req, res, next) => {
  console.error(err);
  res.status(500).render("admin/500-page.ejs"); // You can customize the error response here
});

router.use((req, res, next) => {
  const token = req.cookies.token;

  if (!token) {
    // Token is missing, redirect to login
    return res.redirect("/admin/login");
  }

  try {
    const decoded = jwt.verify(token, secretKey);
    req.username = decoded.username;
    next();
  } catch (error) {
    if (error.name === "TokenExpiredError") {
      // Token has expired, clear the existing token and redirect to login
      res.clearCookie("token");
      return res.redirect("/admin/login");
    } else {
      next(error); // Pass the error to the error handler
    }
  }
});

// Admin Dashboard
router.get("/", async (req, res) => {
  try {
    const sports = await sportsSchema.find();
    res.render("admin/admin.ejs", { sports });
  } catch (error) {
    next(error); // Pass the error to the error handler
  }
});

// Adding a new sport
router.post("/", async (req, res) => {
  const { sportName } = req.body;

  try {
    const newSport = new sportsSchema({
      sportName,
    });

    await newSport.save();
    const sports = await sportsSchema.find();
    res.render("admin/admin.ejs", { sports });
  } catch (error) {
    next(error); // Pass the error to the error handler
  }
});

// Sport Page Routes
router.get("/sport/:sportName", async (req, res) => {
  const { sportName } = req.params;

  try {
    const sport = await sportsSchema.findOne({ sportName });

    if (!sport) {
      res.render("err/404-page.ejs");
    }

    res.render("admin/sport.ejs", { sportName, sport });
  } catch (error) {
    next(error); // Pass the error to the error handler
  }
});

// Adding pages to a sport
router.post("/sport/:sportName", async (req, res) => {
  const { sportName } = req.params;
  const { pagesLimit } = req.body;

  try {
    const sport = await sportsSchema.findOne({ sportName });
    sport.pages = [];

    for (let i = 1; i <= +pagesLimit; i++) {
      sport.pages.push({
        id: Math.floor(Math.random() * 9999999999),
        pageNo: i,
        title: sportName.toUpperCase() + " " + i,
        player: "",
      });
    }

    await sport.save();

    res.render("admin/sport.ejs", { sportName, sport });
  } catch (error) {
    next(error); // Pass the error to the error handler
  }
});

// Deleting a sport
router.post("/sport/delete/:sportName", async (req, res) => {
  const { sportName } = req.params;

  try {
    const result = await sportsSchema.deleteOne({ sportName });

    if (result.deletedCount > 0) {
      res.redirect("/admin");
    } else {
      res.status(404).render("err/404-page.ejs");
    }
  } catch (error) {
    next(error); // Pass the error to the error handler
  }
});

// Edit-Page Routes
router.get("/sport/edit/:sportName/:id", async (req, res) => {
  const { sportName, id } = req.params;

  try {
    const sport = await sportsSchema.findOne({ sportName });
    const page = sport.pages.find((page) => page.id === +id);

    if (!sport || !page) {
      res.render("err/404-page.ejs");
    }

    res.render("admin/editPage.ejs", { sportName, page });
  } catch (error) {
    next(error); // Pass the error to the error handler
  }
});

// Editing a page
router.post("/sport/edit/:sportName/:id", async (req, res) => {
  const { sportName, id } = req.params;
  const { title, frame } = req.body;

  try {
    const result = await sportsSchema.updateOne(
      { sportName, "pages.id": +id },
      { $set: { "pages.$.title": title, "pages.$.player": frame } }
    );

    if (result.nModified === 0) {
      return res.status(404).send("Page not found");
    }

    res.redirect("/admin/sport/" + sportName);
  } catch (error) {
    next(error); // Pass the error to the error handler
  }
});

// CopyLinks Page
router.get("/copylinks/:sportName", async (req, res) => {
  const { sportName } = req.params;

  try {
    const sport = await sportsSchema.findOne({ sportName });

    if (!sport) {
      res.render("err/404-page.ejs");
    }

    res.render("admin/copyLinks.ejs", { sport });
  } catch (error) {
    next(error); // Pass the error to the error handler
  }
});

// Ads Placement Routes

router.get("/adsplacement", async (req, res) => {
  try {
    const ads = await adsSchema.findOne();
    res.render("admin/ads.ejs", { ads });
  } catch (error) {
    next(error); // Pass the error to the error handler
  }
});

router.post("/adsplacement", async (req, res) => {
  const { headAd, topAd, bottomAd, leftAd, rightAd } = req.body;

  try {
    await adsSchema.deleteMany();

    const newAdsPlacement = new adsSchema({
      headAd,
      topAd,
      bottomAd,
      leftAd,
      rightAd,
    });

    await newAdsPlacement.save();

    const ads = await adsSchema.findOne();
    res.render("admin/ads.ejs", { ads });
  } catch (error) {
    next(error); // Pass the error to the error handler
  }
});

module.exports = router;
