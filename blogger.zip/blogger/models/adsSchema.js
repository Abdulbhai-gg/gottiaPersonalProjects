const mongoose = require("mongoose");

const ads = mongoose.Schema({
  headAd: String,
  topAd: String,
  bottomAd: String,
  leftAd: String,
  rightAd: String,
});

module.exports = mongoose.model("adsPlacement", ads);
