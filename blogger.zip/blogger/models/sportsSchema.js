const mongoose = require("mongoose");

const newSport = mongoose.Schema({
  sportName: String,
  pages: Array,
});

module.exports = mongoose.model("newSport", newSport);
