const express = require("express");
const jwt = require("jsonwebtoken");
const router = express.Router();
const sportsSchema = require("../models/sportsSchema.js");
const adsSchema = require("../models/adsSchema.js");

require("dotenv").config(); // Load environment variables from .env
const secretKey = process.env.SECRET_KEY;

// Middleware to protect admin routes
// Middleware to handle TokenExpiredError and verify the token
router.use((req, res, next) => {
  const token = req.cookies.token;

  if (!token) {
    // Token is missing, redirect to login
    return res.redirect("/admin/login");
  }

  try {
    const decoded = jwt.verify(token, secretKey);
    req.username = decoded.username;
    next();
  } catch (error) {
    if (error.name === "TokenExpiredError") {
      // Token has expired, clear the existing token and redirect to login
      res.clearCookie("token");
      return res.redirect("/admin/login");
    } else {
      console.error(error);
      res.clearCookie("token");
      res.redirect("/admin/login");
    }
  }
});

// Admin Dashboard
router.get("/", async (req, res) => {
  try {
    const sports = await sportsSchema.find();
    res.render("admin.ejs", { addedSport: null, sports });
  } catch (error) {
    console.error(error);
    res.status(500).send("Internal Server Error");
  }
});

// Adding a new sport
router.post("/", async (req, res) => {
  const { sportName } = req.body;

  const newSport = new sportsSchema({
    sportName,
  });

  try {
    await newSport.save();
    const sports = await sportsSchema.find();
    res.render("admin.ejs", { addedSport: null, sports });
  } catch (error) {
    console.error(error);
    res.status(500).send("Internal Server Error");
  }
});

// Sport Page Routes
router.get("/sport/:sportName", async (req, res) => {
  const { sportName } = req.params;

  try {
    const sport = await sportsSchema.findOne({ sportName });
    res.render("sport.ejs", { sportName, sport });
  } catch (error) {
    console.error(error);
    res.status(500).send("Internal Server Error");
  }
});

// Adding pages to a sport
router.post("/sport/:sportName", async (req, res) => {
  const { sportName } = req.params;
  const { pagesLimit } = req.body;

  try {
    const sport = await sportsSchema.findOne({ sportName });
    sport.pages = [];

    for (let i = 1; i <= +pagesLimit; i++) {
      sport.pages.push({
        id: Math.floor(Math.random() * 9999999999),
        title: sportName.toUpperCase() + " " + i,
        player: "",
      });
    }

    await sport.save();

    res.render("sport.ejs", { sportName, sport });
  } catch (error) {
    console.error(error);
    res.status(500).send("Internal Server Error");
  }
});

// Deleting a sport
router.post("/sport/delete/:sportName", async (req, res) => {
  const { sportName } = req.params;

  const result = await sportsSchema.deleteOne({ sportName });

  if (result.deletedCount > 0) {
    res.redirect("/admin");
  } else {
    res.status(404).send("Sport not found");
  }
});

// Edit-Page Routes
router.get("/sport/edit/:sportName/:id", async (req, res) => {
  const { sportName, id } = req.params;

  try {
    const sport = await sportsSchema.findOne({ sportName });
    const page = sport.pages.find((page) => page.id === +id);
    res.render("editPage.ejs", { sportName, page });
  } catch (error) {
    console.error(error);
    res.status(500).send("Internal Server Error");
  }
});

// Editing a page
router.post("/sport/edit/:sportName/:id", async (req, res) => {
  const { sportName, id } = req.params;
  const { title, frame } = req.body;

  try {
    const result = await sportsSchema.updateOne(
      { sportName, "pages.id": +id },
      { $set: { "pages.$.title": title, "pages.$.player": frame } }
    );

    if (result.nModified === 0) {
      return res.status(404).send("Page not found");
    }

    res.redirect("/admin/sport/" + sportName);
  } catch (error) {
    console.error(error);
    res.status(500).send("Internal Server Error");
  }
});

// Ads Placement Routes

router.get("/adsplacement", async (req, res) => {
  const ads = await adsSchema.findOne();

  res.render("ads.ejs", { ads });
});

router.post("/adsplacement", async (req, res) => {
  const { headAd, topAd, bottomAd, leftAd, rightAd } = req.body;

  await adsSchema.deleteMany();

  const newAdsPlacement = new adsSchema({
    headAd,
    topAd,
    bottomAd,
    leftAd,
    rightAd,
  });

  await newAdsPlacement.save();

  const ads = await adsSchema.findOne();

  res.render("ads.ejs", { ads });
});

module.exports = router;
