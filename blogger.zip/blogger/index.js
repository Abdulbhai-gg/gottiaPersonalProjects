const express = require("express");
const mongoose = require("mongoose");
const bodyParser = require("body-parser");
const cookieParser = require("cookie-parser");
const ejs = require("ejs");
require("dotenv").config();

const PORT = process.env.PORT || 5000;
const dbConnection = process.env.dbConnection;

const streamPageRoutes = require("./routes/streamPagesRoutes.js");
const authRoutes = require("./routes/authRoutes.js");
const adminRoutes = require("./routes/adminRoutes.js");

mongoose
  .connect(dbConnection, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
  })
  .then(() => {
    console.log("DB Connection Successful");
    startServer();
  })
  .catch((err) => {
    console.error("Error While Connecting to DB:", err);
  });

function startServer() {
  const app = express();

  app.use(express.static(__dirname + "/public"));
  app.use(bodyParser.urlencoded({ extended: false }));
  app.use(cookieParser());

  app.set("view engine", "ejs");

  // Define your routes

  app.use("/admin", authRoutes);
  app.use("/admin", adminRoutes);

  app.use("/", streamPageRoutes);

  // Handle 404 errors
  app.use((req, res) => {
    res.status(404).render("404-page.ejs");
  });

  // Custom error handling middleware
  app.use((err, req, res) => {
    console.error("Internal Server Error:", err);
    res.status(500).render("500-page.ejs");
  });

  app.listen(PORT, () => {
    console.log(`Server Listening on port ${PORT}`);
  });
}
